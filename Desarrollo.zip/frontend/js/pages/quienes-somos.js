/**
 * ═══════════════════════════════════════════════════════════════════════════
 * MARAZUL E-COMMERCE - PÁGINA QUIÉNES SOMOS
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Página institucional estática que carga componentes dinámicos
 * (header y carrito) y muestra información sobre la empresa.
 * 
 * Esta página no requiere lógica compleja, solo carga de componentes.
 * 
 * Fecha: 26 Noviembre 2025
 * Versión: 1.0.0
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ═══════════════════════════════════════════════════════════════════════════
// INICIALIZACIÓN
// ═══════════════════════════════════════════════════════════════════════════

$(document).ready(function() {
  console.log('📖 Inicializando página Quiénes Somos...');
  
  // Cargar componentes dinámicos
  loadPageComponents();
});

/**
 * Carga los componentes dinámicos de la página
 * (header y carrito)
 */
function loadPageComponents() {
  // Cargar header
  UTILS.loadComponent('header-container', 'header.html', function() {
    if (typeof initHeader === 'function') {
      initHeader();
    }
    console.log('✅ Header cargado');
  });
  
  // Cargar carrito
  UTILS.loadComponent('carrito-container', 'carrito.html', function() {
    console.log('✅ Carrito cargado');
  });
  
  console.log('✅ Componentes de Quiénes Somos inicializados');
}

// ═══════════════════════════════════════════════════════════════════════════
// LOG DE INICIALIZACIÓN
// ═══════════════════════════════════════════════════════════════════════════

console.log('✅ quienes-somos.js cargado correctamente');